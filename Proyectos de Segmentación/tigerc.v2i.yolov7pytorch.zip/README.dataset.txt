# tigerc > 2023-03-19 11:54am
https://universe.roboflow.com/instance-segmentation/tigerc

Provided by a Roboflow user
License: CC BY 4.0

